#ifndef __CTR_TASK_H__
#define __CTR_TASK_H__


#include "motor_pid.h"

extern float motor_pid_out[2];

#endif
