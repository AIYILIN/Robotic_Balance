#ifndef __KEY_TASK_H__
#define __KEY_TASK_H__

#define KEY_ON          1
#define KEY_OFF         0

#include "stdint.h"

extern uint8_t key_status ;

#endif
