#ifndef __RGB_TASK_H__
#define __RGB_TASK_H__

#define RGB_LIGHT_LIMIT 30
#define RGB_DELAY_TIME 50

#endif
